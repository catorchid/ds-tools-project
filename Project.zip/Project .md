```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as plticker
import seaborn as sns
import scipy.stats as ss
from sklearn.preprocessing import minmax_scale 
import re
import warnings
warnings.filterwarnings('ignore')
import sweetviz as sv
sns.set(style="darkgrid")
pd.options.display.show_dimensions=False
pd.options.display.width = 80
pd.options.display.max_colwidth = 10
pd.options.display.max_columns = 80
pd.set_option('display.max_rows',None)
```

Citation:
juntarawijit, chudchawal (2014-2017). Pesticide and lung cancer. figshare. Dataset. https://doi.org/10.6084/m9.figshare.12356270.v5

Data was analyzed prior to this analysis and presented in research paper: Pesticide exposure and lung cancer risk: A case-control study in Nakhon Sawan, Thailand : Teera Kangkhetkron and Chudchawal Juntarawijit (2020)

The dataset contains 68 columns which record responses of participants in Nakhon Sawan province, Thailand by in-person questionaire. 233 lung cancer cases, and 458 healthy neighbours matched for gender, and age (±5 years) were questioned about pesticides and other types of environmental exposures.  Demographic data, distance to nearest farm land, air pollution exposures, cigarette smoking habits were collected. Many of the features were recorded in multiple forms such as yes or no, number of days, total per year, etc.                                                          Many cells were left empty when the field is a quantity following a no exposure response. 
 
Cigarette smoking was recorded in 5 different columns.  Here we will look at Cigarette_number and CigSmoke_status.                                                 
For full descriptions refer to the Data Dictionary: https://figshare.com/articles/dataset/Pesticide_and_lung_cancer/12356270/5?file=39615298

Target: ID:  Float data. .0 as control, no lung cancer and .(1-9) as lung cancer

LungCA: Lung cancer status of responders: 0  as control and 1 as having lung cancer

Cigarette_number: the number of cigarettes smoked per day

CigSmoke_status: Tobacco status of responders, 1 refers those who have never smoked a cigarette, 2 refers to ex-smoker, 3 refers to
current smoker

age_group: Responders in each group; 
1 refers to those with age less than or equal to 54, 
2 refer to those with age 55-64 yr, 
3 refer to those with age 65-74 yr, 
4 refer to those with age 75 yr or more

Herbicide_days, Number_Days_Insecticides_Use_432 and Number_Days_Fungicides_Use_433 are cummulative columns calculated as number of days * number of years. 

Problem statement:   Lung cancer has long been a cause of human mortality with cigarette smoking being a known contributor. Airborne envirnomental exposures are a daily occurrence across the globe, such as, exhaust from industry and vehicles, vapors from cooking and cleaning or the use of pesticides, fungicides and herbicides across farmlands. The goal of this analysis is to determine if other environmental exposures increase the incident lung cancers. 


```python
lung_cancer = pd.read_csv('https://raw.githubusercontent.com/catorchid/ds-tools-project/main/Dataset%20pesticide%20and%20lung%20cancer.csv')
lung_cancer.sample(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LungCA</th>
      <th>Gender</th>
      <th>age</th>
      <th>age_group</th>
      <th>status</th>
      <th>education</th>
      <th>Occupation</th>
      <th>Residency</th>
      <th>Distances</th>
      <th>Cooking_fumes</th>
      <th>Air_Pollution_Exposure</th>
      <th>CigSmoke1</th>
      <th>CigSmoke2</th>
      <th>Cigarette_total</th>
      <th>Cigarette_year</th>
      <th>Cigarette_number</th>
      <th>CigSmoke_status</th>
      <th>Herbicides</th>
      <th>Herbicides_year</th>
      <th>Herbicide_year_group</th>
      <th>Herbicide_day</th>
      <th>Number_Days_Herbicides_Use_Quartile_431</th>
      <th>Insecticides_Use_432</th>
      <th>Number_Years_Insecticides_Use_432</th>
      <th>Number_Years_Insecticides_Use_Group_432</th>
      <th>Number_Days_Insecticides_Use_432</th>
      <th>Number_Days_Insecticides_Use_Quartile_432</th>
      <th>Fungicides_Use_433</th>
      <th>Number_Years_Fungticides_Use_433</th>
      <th>Number_Years_Fungicides_Use_Group_433</th>
      <th>Number_Days_Fungicides_Use_433</th>
      <th>Number_Days_Fungicides_Use_Quartile_433</th>
      <th>Glyphosate_use</th>
      <th>Glyphosate_days</th>
      <th>Paraquat_use</th>
      <th>Paraquat_days</th>
      <th>two_four_Dichlorophenoxy_use</th>
      <th>two_four_Dichlorophenoxy_days</th>
      <th>Butachlor_use</th>
      <th>Butachlor_Days</th>
      <th>Propanil_use</th>
      <th>Propanil_days</th>
      <th>Alachlor_use</th>
      <th>Alachlor_days</th>
      <th>Endosalfan_use</th>
      <th>Endosalfan_days</th>
      <th>Dieldrin_use</th>
      <th>Dieldrin_days</th>
      <th>DDT_use</th>
      <th>DDT_days</th>
      <th>Chlorpylifos_use</th>
      <th>Chlorpylifos_days</th>
      <th>Folidol_use</th>
      <th>Folidol_days</th>
      <th>Mevinphos_use</th>
      <th>Mevinphos_days</th>
      <th>Carbaryl_Savins_use</th>
      <th>Carbaryl_Savins_days</th>
      <th>Carbofuran_use</th>
      <th>Carbofuran_days</th>
      <th>Abamectin_use</th>
      <th>Abamectin_days</th>
      <th>Armure_Propiconazole_use</th>
      <th>Armure_Propiconazole_days</th>
      <th>Metal_aldehyde_use</th>
      <th>Metal_aldehyde_days</th>
      <th>Morphology_Group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>216</th>
      <td>73.0</td>
      <td>1</td>
      <td>1</td>
      <td>77</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>2</td>
      <td>600</td>
      <td>3</td>
      <td>1</td>
      <td>30</td>
      <td>2</td>
      <td>460</td>
      <td>2</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>1</td>
      <td>160</td>
      <td>1</td>
      <td>160</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>720</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>1</td>
      <td>200</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>3</td>
    </tr>
    <tr>
      <th>138</th>
      <td>47.0</td>
      <td>1</td>
      <td>0</td>
      <td>62</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>5475</td>
      <td>5</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>1</td>
      <td>400</td>
      <td>1</td>
    </tr>
    <tr>
      <th>84</th>
      <td>29.0</td>
      <td>1</td>
      <td>0</td>
      <td>79</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>73000</td>
      <td>20</td>
      <td>10</td>
      <td>2</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>1</td>
    </tr>
    <tr>
      <th>211</th>
      <td>71.1</td>
      <td>0</td>
      <td>0</td>
      <td>63</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
    </tr>
    <tr>
      <th>357</th>
      <td>122.1</td>
      <td>0</td>
      <td>1</td>
      <td>63</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>1</td>
      <td>33</td>
      <td>1</td>
      <td>33</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
    </tr>
    <tr>
      <th>142</th>
      <td>48.1</td>
      <td>0</td>
      <td>0</td>
      <td>65</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>2</td>
      <td>600</td>
      <td>3</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
    </tr>
    <tr>
      <th>567</th>
      <td>227.1</td>
      <td>0</td>
      <td>1</td>
      <td>74</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>219000</td>
      <td>60</td>
      <td>10</td>
      <td>2</td>
      <td>1</td>
      <td>40</td>
      <td>3</td>
      <td>1680</td>
      <td>4</td>
      <td>1</td>
      <td>40</td>
      <td>3</td>
      <td>1600</td>
      <td>4</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>1</td>
      <td>160</td>
      <td>1</td>
      <td>160</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>1</td>
      <td>1680</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
    </tr>
    <tr>
      <th>73</th>
      <td>25.1</td>
      <td>0</td>
      <td>0</td>
      <td>82</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
    </tr>
    <tr>
      <th>44</th>
      <td>15.2</td>
      <td>0</td>
      <td>0</td>
      <td>68</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>2</td>
      <td>80</td>
      <td>1</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>1</td>
      <td>1440</td>
      <td>1</td>
      <td>640</td>
      <td>1</td>
      <td>640</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
    </tr>
    <tr>
      <th>666</th>
      <td>287.1</td>
      <td>0</td>
      <td>1</td>
      <td>74</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>30</td>
      <td>2</td>
      <td>600</td>
      <td>3</td>
      <td>1</td>
      <td>30</td>
      <td>2</td>
      <td>280</td>
      <td>2</td>
      <td>0</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>400</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td></td>
      <td>1</td>
      <td>32</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>1</td>
      <td>270</td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
      <td></td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
lung_cancer.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 680 entries, 0 to 679
    Data columns (total 68 columns):
     #   Column                                     Non-Null Count  Dtype  
    ---  ------                                     --------------  -----  
     0   ID                                         680 non-null    float64
     1   LungCA                                     680 non-null    int64  
     2   Gender                                     680 non-null    int64  
     3   age                                        680 non-null    int64  
     4   age_group                                  680 non-null    int64  
     5   status                                     680 non-null    int64  
     6   education                                  680 non-null    int64  
     7   Occupation                                 680 non-null    int64  
     8   Residency                                  680 non-null    int64  
     9   Distances                                  680 non-null    int64  
     10  Cooking_fumes                              680 non-null    int64  
     11  Air_Pollution_Exposure                     680 non-null    int64  
     12  CigSmoke1                                  680 non-null    int64  
     13  CigSmoke2                                  680 non-null    int64  
     14  Cigarette_total                            680 non-null    object 
     15  Cigarette_year                             680 non-null    int64  
     16  Cigarette_number                           680 non-null    object 
     17  CigSmoke_status                            680 non-null    int64  
     18  Herbicides                                 680 non-null    int64  
     19  Herbicides_year                            680 non-null    object 
     20  Herbicide_year_group                       680 non-null    object 
     21  Herbicide_day                              680 non-null    object 
     22  Number_Days_Herbicides_Use_Quartile_431    680 non-null    object 
     23  Insecticides_Use_432                       680 non-null    int64  
     24  Number_Years_Insecticides_Use_432          680 non-null    object 
     25  Number_Years_Insecticides_Use_Group_432    680 non-null    object 
     26  Number_Days_Insecticides_Use_432           680 non-null    object 
     27  Number_Days_Insecticides_Use_Quartile_432  680 non-null    object 
     28  Fungicides_Use_433                         680 non-null    int64  
     29  Number_Years_Fungticides_Use_433           680 non-null    object 
     30  Number_Years_Fungicides_Use_Group_433      680 non-null    object 
     31  Number_Days_Fungicides_Use_433             680 non-null    object 
     32  Number_Days_Fungicides_Use_Quartile_433    680 non-null    object 
     33  Glyphosate_use                             680 non-null    int64  
     34  Glyphosate_days                            680 non-null    int64  
     35  Paraquat_use                               680 non-null    int64  
     36  Paraquat_days                              680 non-null    int64  
     37  two_four_Dichlorophenoxy_use               680 non-null    int64  
     38  two_four_Dichlorophenoxy_days              680 non-null    int64  
     39  Butachlor_use                              680 non-null    int64  
     40  Butachlor_Days                             680 non-null    int64  
     41  Propanil_use                               680 non-null    int64  
     42  Propanil_days                              680 non-null    int64  
     43  Alachlor_use                               680 non-null    int64  
     44  Alachlor_days                              680 non-null    int64  
     45  Endosalfan_use                             680 non-null    int64  
     46  Endosalfan_days                            680 non-null    int64  
     47  Dieldrin_use                               680 non-null    int64  
     48  Dieldrin_days                              680 non-null    object 
     49  DDT_use                                    680 non-null    int64  
     50  DDT_days                                   680 non-null    object 
     51  Chlorpylifos_use                           680 non-null    int64  
     52  Chlorpylifos_days                          680 non-null    object 
     53  Folidol_use                                680 non-null    int64  
     54  Folidol_days                               680 non-null    object 
     55  Mevinphos_use                              680 non-null    int64  
     56  Mevinphos_days                             680 non-null    object 
     57  Carbaryl_Savins_use                        680 non-null    int64  
     58  Carbaryl_Savins_days                       680 non-null    object 
     59  Carbofuran_use                             680 non-null    int64  
     60  Carbofuran_days                            680 non-null    object 
     61  Abamectin_use                              680 non-null    int64  
     62  Abamectin_days                             680 non-null    object 
     63  Armure_Propiconazole_use                   680 non-null    int64  
     64  Armure_Propiconazole_days                  680 non-null    object 
     65  Metal_aldehyde_use                         680 non-null    int64  
     66  Metal_aldehyde_days                        680 non-null    object 
     67  Morphology_Group                           680 non-null    int64  
    dtypes: float64(1), int64(43), object(24)
    memory usage: 361.4+ KB
    

Although isna returns 0 for all columns, there are empty cells. Regex to replace empty cells with 0. All empty cells refer to a quantity where the reponse to exposure is no.  We can safely apply 0 here as it follows there would be no # of cigarettes smoked or days in which an exposure occurred. 


```python
lung_cancer = lung_cancer.replace(r'^\s*$', 0, regex=True)
lung_cancer.sample(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LungCA</th>
      <th>Gender</th>
      <th>age</th>
      <th>age_group</th>
      <th>status</th>
      <th>education</th>
      <th>Occupation</th>
      <th>Residency</th>
      <th>Distances</th>
      <th>Cooking_fumes</th>
      <th>Air_Pollution_Exposure</th>
      <th>CigSmoke1</th>
      <th>CigSmoke2</th>
      <th>Cigarette_total</th>
      <th>Cigarette_year</th>
      <th>Cigarette_number</th>
      <th>CigSmoke_status</th>
      <th>Herbicides</th>
      <th>Herbicides_year</th>
      <th>Herbicide_year_group</th>
      <th>Herbicide_day</th>
      <th>Number_Days_Herbicides_Use_Quartile_431</th>
      <th>Insecticides_Use_432</th>
      <th>Number_Years_Insecticides_Use_432</th>
      <th>Number_Years_Insecticides_Use_Group_432</th>
      <th>Number_Days_Insecticides_Use_432</th>
      <th>Number_Days_Insecticides_Use_Quartile_432</th>
      <th>Fungicides_Use_433</th>
      <th>Number_Years_Fungticides_Use_433</th>
      <th>Number_Years_Fungicides_Use_Group_433</th>
      <th>Number_Days_Fungicides_Use_433</th>
      <th>Number_Days_Fungicides_Use_Quartile_433</th>
      <th>Glyphosate_use</th>
      <th>Glyphosate_days</th>
      <th>Paraquat_use</th>
      <th>Paraquat_days</th>
      <th>two_four_Dichlorophenoxy_use</th>
      <th>two_four_Dichlorophenoxy_days</th>
      <th>Butachlor_use</th>
      <th>Butachlor_Days</th>
      <th>Propanil_use</th>
      <th>Propanil_days</th>
      <th>Alachlor_use</th>
      <th>Alachlor_days</th>
      <th>Endosalfan_use</th>
      <th>Endosalfan_days</th>
      <th>Dieldrin_use</th>
      <th>Dieldrin_days</th>
      <th>DDT_use</th>
      <th>DDT_days</th>
      <th>Chlorpylifos_use</th>
      <th>Chlorpylifos_days</th>
      <th>Folidol_use</th>
      <th>Folidol_days</th>
      <th>Mevinphos_use</th>
      <th>Mevinphos_days</th>
      <th>Carbaryl_Savins_use</th>
      <th>Carbaryl_Savins_days</th>
      <th>Carbofuran_use</th>
      <th>Carbofuran_days</th>
      <th>Abamectin_use</th>
      <th>Abamectin_days</th>
      <th>Armure_Propiconazole_use</th>
      <th>Armure_Propiconazole_days</th>
      <th>Metal_aldehyde_use</th>
      <th>Metal_aldehyde_days</th>
      <th>Morphology_Group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>223</th>
      <td>75.1</td>
      <td>0</td>
      <td>1</td>
      <td>42</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>308</th>
      <td>103.2</td>
      <td>0</td>
      <td>0</td>
      <td>70</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2000</td>
      <td>1</td>
      <td>2000</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>367</th>
      <td>125.2</td>
      <td>0</td>
      <td>1</td>
      <td>72</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>54750</td>
      <td>30</td>
      <td>5</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>187</th>
      <td>63.1</td>
      <td>0</td>
      <td>1</td>
      <td>85</td>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>32</th>
      <td>11.2</td>
      <td>0</td>
      <td>0</td>
      <td>55</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>480</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>258</th>
      <td>87.0</td>
      <td>1</td>
      <td>0</td>
      <td>52</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>306600</td>
      <td>42</td>
      <td>20</td>
      <td>2</td>
      <td>1</td>
      <td>42</td>
      <td>3</td>
      <td>672</td>
      <td>3</td>
      <td>1</td>
      <td>35</td>
      <td>3</td>
      <td>560</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>560</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>208</th>
      <td>70.1</td>
      <td>0</td>
      <td>0</td>
      <td>69</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>71175</td>
      <td>39</td>
      <td>5</td>
      <td>2</td>
      <td>1</td>
      <td>39</td>
      <td>3</td>
      <td>936</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1440</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>160</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>659</th>
      <td>285.0</td>
      <td>1</td>
      <td>0</td>
      <td>57</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>25</td>
      <td>2</td>
      <td>2000</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
      <td>2</td>
      <td>600</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>45</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>90</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>30</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>120</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>90</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>370</td>
      <td>3</td>
    </tr>
    <tr>
      <th>143</th>
      <td>48.2</td>
      <td>0</td>
      <td>0</td>
      <td>56</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>73000</td>
      <td>20</td>
      <td>10</td>
      <td>2</td>
      <td>1</td>
      <td>20</td>
      <td>2</td>
      <td>600</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>120</td>
      <td>1</td>
      <td>360</td>
      <td>1</td>
      <td>10</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>479</th>
      <td>174.0</td>
      <td>1</td>
      <td>0</td>
      <td>72</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>20</td>
      <td>2</td>
      <td>600</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1200</td>
      <td>1</td>
      <td>1200</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
# heatmap containing all 68 features.  Not very useful but we can see some areas of high correlation do exist
sns.set(font_scale=1)
fig, ax = plt.subplots(figsize=(30, 30))
coeff=lung_cancer.corr()
sns.heatmap(coeff)
```




    <Axes: >




    
![png](output_9_1.png)
    



```python
lung_cancer.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LungCA</th>
      <th>Gender</th>
      <th>age</th>
      <th>age_group</th>
      <th>status</th>
      <th>education</th>
      <th>Occupation</th>
      <th>Residency</th>
      <th>Distances</th>
      <th>Cooking_fumes</th>
      <th>Air_Pollution_Exposure</th>
      <th>CigSmoke1</th>
      <th>CigSmoke2</th>
      <th>Cigarette_year</th>
      <th>CigSmoke_status</th>
      <th>Herbicides</th>
      <th>Insecticides_Use_432</th>
      <th>Fungicides_Use_433</th>
      <th>Glyphosate_use</th>
      <th>Glyphosate_days</th>
      <th>Paraquat_use</th>
      <th>Paraquat_days</th>
      <th>two_four_Dichlorophenoxy_use</th>
      <th>two_four_Dichlorophenoxy_days</th>
      <th>Butachlor_use</th>
      <th>Butachlor_Days</th>
      <th>Propanil_use</th>
      <th>Propanil_days</th>
      <th>Alachlor_use</th>
      <th>Alachlor_days</th>
      <th>Endosalfan_use</th>
      <th>Endosalfan_days</th>
      <th>Dieldrin_use</th>
      <th>DDT_use</th>
      <th>Chlorpylifos_use</th>
      <th>Folidol_use</th>
      <th>Mevinphos_use</th>
      <th>Carbaryl_Savins_use</th>
      <th>Carbofuran_use</th>
      <th>Abamectin_use</th>
      <th>Armure_Propiconazole_use</th>
      <th>Metal_aldehyde_use</th>
      <th>Morphology_Group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
      <td>680.00...</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>127.80...</td>
      <td>0.342647</td>
      <td>0.589706</td>
      <td>65.600000</td>
      <td>2.627941</td>
      <td>2.069118</td>
      <td>1.101471</td>
      <td>1.436765</td>
      <td>2.650000</td>
      <td>1.994118</td>
      <td>1.679412</td>
      <td>0.485294</td>
      <td>0.650000</td>
      <td>0.529412</td>
      <td>10.352941</td>
      <td>1.448529</td>
      <td>0.510294</td>
      <td>0.448529</td>
      <td>0.170588</td>
      <td>0.413235</td>
      <td>300.29...</td>
      <td>0.354412</td>
      <td>229.48...</td>
      <td>0.170588</td>
      <td>73.364706</td>
      <td>0.055882</td>
      <td>14.964706</td>
      <td>0.047059</td>
      <td>8.917647</td>
      <td>0.063235</td>
      <td>39.944118</td>
      <td>0.116176</td>
      <td>71.850000</td>
      <td>0.064706</td>
      <td>0.073529</td>
      <td>0.102941</td>
      <td>0.152941</td>
      <td>0.055882</td>
      <td>0.070588</td>
      <td>0.125000</td>
      <td>0.197059</td>
      <td>0.117647</td>
      <td>0.063235</td>
      <td>0.898529</td>
    </tr>
    <tr>
      <th>std</th>
      <td>83.800673</td>
      <td>0.474944</td>
      <td>0.492249</td>
      <td>10.794724</td>
      <td>1.002845</td>
      <td>0.440497</td>
      <td>0.338929</td>
      <td>0.496350</td>
      <td>0.658802</td>
      <td>0.935297</td>
      <td>0.467046</td>
      <td>0.500152</td>
      <td>0.477321</td>
      <td>0.780291</td>
      <td>17.160135</td>
      <td>0.667131</td>
      <td>0.500262</td>
      <td>0.497710</td>
      <td>0.376426</td>
      <td>0.492777</td>
      <td>654.43...</td>
      <td>0.478687</td>
      <td>582.35...</td>
      <td>0.376426</td>
      <td>301.64...</td>
      <td>0.229863</td>
      <td>126.74...</td>
      <td>0.211921</td>
      <td>60.095302</td>
      <td>0.243565</td>
      <td>249.02...</td>
      <td>0.320672</td>
      <td>333.85...</td>
      <td>0.246187</td>
      <td>0.261196</td>
      <td>0.304106</td>
      <td>0.360196</td>
      <td>0.229863</td>
      <td>0.256324</td>
      <td>0.330962</td>
      <td>0.398070</td>
      <td>0.322427</td>
      <td>0.243565</td>
      <td>1.632692</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>31.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>57.175000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>58.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>114.15...</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>66.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>189.02...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>74.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>15.250000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>338.00...</td>
      <td>1.000000</td>
      <td>160.00...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>292.20...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>98.000000</td>
      <td>4.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>70.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>5760.0...</td>
      <td>1.000000</td>
      <td>5760.0...</td>
      <td>1.000000</td>
      <td>3600.0...</td>
      <td>1.000000</td>
      <td>1920.0...</td>
      <td>1.000000</td>
      <td>660.00...</td>
      <td>1.000000</td>
      <td>3600.0...</td>
      <td>1.000000</td>
      <td>5460.0...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>6.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# New df containing columns of interest
lung_cancer_trunc = lung_cancer[['ID','LungCA','age_group','Gender','CigSmoke_status','Cigarette_number','Cigarette_total','Cooking_fumes','Air_Pollution_Exposure','Herbicide_day',
'Number_Days_Insecticides_Use_432','Number_Days_Fungicides_Use_433','Glyphosate_days','Paraquat_days','two_four_Dichlorophenoxy_days',
'Butachlor_Days','Propanil_days','Alachlor_days','Endosalfan_days','Dieldrin_days','DDT_days','Chlorpylifos_days','Folidol_days',
'Mevinphos_days','Carbaryl_Savins_days','Carbofuran_days','Abamectin_days','Armure_Propiconazole_days','Metal_aldehyde_days']]
```


```python
lung_cancer_trunc.drop(['ID'], axis=1, inplace = True)
lung_cancer_trunc=lung_cancer_trunc.astype(int)
lung_cancer_trunc['ID']=lung_cancer['ID']
```


```python
lung_cancer_trunc.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LungCA</th>
      <th>age_group</th>
      <th>Gender</th>
      <th>CigSmoke_status</th>
      <th>Cigarette_number</th>
      <th>Cigarette_total</th>
      <th>Cooking_fumes</th>
      <th>Air_Pollution_Exposure</th>
      <th>Herbicide_day</th>
      <th>Number_Days_Insecticides_Use_432</th>
      <th>Number_Days_Fungicides_Use_433</th>
      <th>Glyphosate_days</th>
      <th>Paraquat_days</th>
      <th>two_four_Dichlorophenoxy_days</th>
      <th>Butachlor_Days</th>
      <th>Propanil_days</th>
      <th>Alachlor_days</th>
      <th>Endosalfan_days</th>
      <th>Dieldrin_days</th>
      <th>DDT_days</th>
      <th>Chlorpylifos_days</th>
      <th>Folidol_days</th>
      <th>Mevinphos_days</th>
      <th>Carbaryl_Savins_days</th>
      <th>Carbofuran_days</th>
      <th>Abamectin_days</th>
      <th>Armure_Propiconazole_days</th>
      <th>Metal_aldehyde_days</th>
      <th>ID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>74</th>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>960</td>
      <td>240</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25.2</td>
    </tr>
    <tr>
      <th>68</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>10</td>
      <td>98550</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>23.2</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>600</td>
      <td>600</td>
      <td>0</td>
      <td>528</td>
      <td>0</td>
      <td>528</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>600</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5.1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>90</td>
      <td>135</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>135</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.2</td>
    </tr>
    <tr>
      <th>661</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>90</td>
      <td>130</td>
      <td>0</td>
      <td>1600</td>
      <td>1600</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>135</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>285.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
lung_cancer_trunc.dtypes
```




    LungCA                                int32
    age_group                             int32
    Gender                                int32
    CigSmoke_status                       int32
    Cigarette_number                      int32
    Cigarette_total                       int32
    Cooking_fumes                         int32
    Air_Pollution_Exposure                int32
    Herbicide_day                         int32
    Number_Days_Insecticides_Use_432      int32
    Number_Days_Fungicides_Use_433        int32
    Glyphosate_days                       int32
    Paraquat_days                         int32
    two_four_Dichlorophenoxy_days         int32
    Butachlor_Days                        int32
    Propanil_days                         int32
    Alachlor_days                         int32
    Endosalfan_days                       int32
    Dieldrin_days                         int32
    DDT_days                              int32
    Chlorpylifos_days                     int32
    Folidol_days                          int32
    Mevinphos_days                        int32
    Carbaryl_Savins_days                  int32
    Carbofuran_days                       int32
    Abamectin_days                        int32
    Armure_Propiconazole_days             int32
    Metal_aldehyde_days                   int32
    ID                                  float64
    dtype: object



Contribution of cigarette smoking to lung cancer development by age group.   As the average number of cigarettes smoked per day increases, so does the number of lung cancer cases. There is a correlation between increased smoking and lung cancer.  Age may also be a factor but further investigation would be needed. 


```python
palette = sns.cubehelix_palette(light=.6, n_colors=2)
g = sns.relplot(
    data=lung_cancer_trunc, kind="line",
    x="age_group", y="Cigarette_total", 
    palette=palette, height=3,
    col='LungCA'
)
g1 = sns.relplot(
    data=lung_cancer_trunc, kind="line",
    x="age_group", y="Cigarette_total", 
    palette=palette, height=3,
    col='LungCA'
)
g.set_axis_labels("Age Group", "Ave Cigarettes/Lifetime")
g1.set_axis_labels("Age Group", "Smoking Status")
```




    <seaborn.axisgrid.FacetGrid at 0x18eb6ca7850>




    
![png](output_16_1.png)
    



    
![png](output_16_2.png)
    



```python
# melt the dataframe so all the "Y Val Row *" values are in the same column
dfmelt1 = pd.melt(lung_cancer_trunc, id_vars=['age_group', 'CigSmoke_status', 'Cigarette_total','LungCA'], 
                     value_vars=['Cooking_fumes', 'Air_Pollution_Exposure', 'Herbicide_day',
                     'Number_Days_Insecticides_Use_432'],
                     var_name="variable", value_name="value")

# make the relplot, limiting the sharey flag to each row
gm = sns.relplot(data=dfmelt1, row="variable", y="value", x="age_group", 
                 col="CigSmoke_status", hue="LungCA", kind="line",
                 palette=palette, height=3,facet_kws={"sharey":"row"})

# pull the "Y Val Row *" label from each graph title onto the row y label
# this assumes the current default behavior seaborn.relplot for graph titling
for row in gm.axes:
    for ax in row:
        title = ax.title.get_text()
        ax.set_title(title.split(" | ")[1])
    row[0].set_ylabel(title.split(" | ")[0].replace("variable = ", ""))
```


    
![png](output_17_0.png)
    


Observations: Air pollutions appears to be a contributing factor to lung cancer when coupled with cigarette smoking.  As general terms, herbicides appear to be a lung cancer risk across all groups and ages.  Insecticides may increase the risk for smokers. Thankfully, cooking fumes do not appear to cause any additional risk.  We won't need to resort to raw eggs in our milk and uncooked veggies. 


```python
dfmelt2 = pd.melt(lung_cancer_trunc, id_vars=['age_group', 'CigSmoke_status', 'Cigarette_total', 'LungCA'], 
                     value_vars=['Number_Days_Fungicides_Use_433',
                     'Glyphosate_days','Paraquat_days','two_four_Dichlorophenoxy_days'],
                     var_name="variable", value_name="value")
gm2 = sns.relplot(data=dfmelt2, row="variable", y="value", x="age_group", 
                 col="CigSmoke_status", hue="LungCA", kind="line",
                 palette=palette, height=3,facet_kws={"sharey":"row"})
for row in gm2.axes:
    for ax in row:
        title = ax.title.get_text()
        ax.set_title(title.split(" | ")[1])
    row[0].set_ylabel(title.split(" | ")[0].replace("variable = ", ""))
```


    
![png](output_19_0.png)
    


Observations: Largely inconclusive but the general fungicide catagory may increase risk of lung cancer. 


```python
dfmelt3 = pd.melt(lung_cancer_trunc, id_vars=['age_group', 'CigSmoke_status','Cigarette_total', 'LungCA'], 
                     value_vars=['Butachlor_Days','Propanil_days','Alachlor_days','Endosalfan_days'],
                     var_name="variable", value_name="value")
gm3 = sns.relplot(data=dfmelt3, row="variable", y="value", x="age_group", 
                 col="CigSmoke_status", hue="LungCA", kind="line",
                 palette=palette, height=3,facet_kws={"sharey":"row"})
for row in gm3.axes:
    for ax in row:
        title = ax.title.get_text()
        ax.set_title(title.split(" | ")[1])
    row[0].set_ylabel(title.split(" | ")[0].replace("variable = ", ""))
```


    
![png](output_21_0.png)
    


Observations: Alachlor and Endosalfan might increase risk. 


```python
dfmelt4 = pd.melt(lung_cancer_trunc, id_vars=['age_group', 'CigSmoke_status', 'Cigarette_total','LungCA'], 
                     value_vars=['Dieldrin_days','DDT_days','Chlorpylifos_days','Folidol_days'],
                     var_name="variable", value_name="value")
gm4 = sns.relplot(data=dfmelt4, row="variable", y="value", x="age_group", 
                 col="CigSmoke_status", hue="LungCA", kind="line",
                 palette=palette, height=3,facet_kws={"sharey":"row"})
for row in gm4.axes:
    for ax in row:
        title = ax.title.get_text()
        ax.set_title(title.split(" | ")[1])
    row[0].set_ylabel(title.split(" | ")[0].replace("variable = ", ""))
```


    
![png](output_23_0.png)
    


Observations: Dieldrin, and Chlorpylifos appear to increase lung cancer risk.  Foidol is a possible risk. 


```python
dfmelt5 = pd.melt(lung_cancer_trunc, id_vars=['age_group', 'CigSmoke_status','Cigarette_total', 'LungCA'], 
                     value_vars=['Mevinphos_days','Carbaryl_Savins_days','Carbofuran_days','Abamectin_days',
                     'Armure_Propiconazole_days','Metal_aldehyde_days'],
                     var_name="variable", value_name="value")
gm5 = sns.relplot(data=dfmelt5, row="variable", y="value", x="age_group", 
                 col="CigSmoke_status", hue="LungCA", kind="line",
                 palette=palette, height=3,facet_kws={"sharey":"row"})
for row in gm5.axes:
    for ax in row:
        title = ax.title.get_text()
        ax.set_title(title.split(" | ")[1])
    row[0].set_ylabel(title.split(" | ")[0].replace("variable = ", ""))
```


    
![png](output_25_0.png)
    


Observations: Carbofuran (insecticide used world-wide on crops) and Mevinphos (insecticide used mainly on vegetables) both appear strongly correlated. The other 4 may be risk factors when combined with smoking and/or age. 

create a new column for total_exposures which contains the sum of all exposures excluding cigarettes


```python
lung_cancer_trunc['Total_exposures'] = lung_cancer_trunc.iloc[:,7:9].sum(axis=1)
lung_cancer_trunc.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LungCA</th>
      <th>age_group</th>
      <th>Gender</th>
      <th>CigSmoke_status</th>
      <th>Cigarette_number</th>
      <th>Cigarette_total</th>
      <th>Cooking_fumes</th>
      <th>Air_Pollution_Exposure</th>
      <th>Herbicide_day</th>
      <th>Number_Days_Insecticides_Use_432</th>
      <th>Number_Days_Fungicides_Use_433</th>
      <th>Glyphosate_days</th>
      <th>Paraquat_days</th>
      <th>two_four_Dichlorophenoxy_days</th>
      <th>Butachlor_Days</th>
      <th>Propanil_days</th>
      <th>Alachlor_days</th>
      <th>Endosalfan_days</th>
      <th>Dieldrin_days</th>
      <th>DDT_days</th>
      <th>Chlorpylifos_days</th>
      <th>Folidol_days</th>
      <th>Mevinphos_days</th>
      <th>Carbaryl_Savins_days</th>
      <th>Carbofuran_days</th>
      <th>Abamectin_days</th>
      <th>Armure_Propiconazole_days</th>
      <th>Metal_aldehyde_days</th>
      <th>ID</th>
      <th>Total_exposures</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>402</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>480</td>
      <td>260</td>
      <td>120</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>840</td>
      <td>0</td>
      <td>80</td>
      <td>560</td>
      <td>0</td>
      <td>0</td>
      <td>60</td>
      <td>0</td>
      <td>60</td>
      <td>120</td>
      <td>0</td>
      <td>139.1</td>
      <td>480</td>
    </tr>
    <tr>
      <th>47</th>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>120</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>120</td>
      <td>0</td>
      <td>16.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>545</th>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>600</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>208.1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>73</th>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25.1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>429</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>10</td>
      <td>109500</td>
      <td>1</td>
      <td>1</td>
      <td>800</td>
      <td>360</td>
      <td>0</td>
      <td>144</td>
      <td>144</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>360</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>154.1</td>
      <td>801</td>
    </tr>
  </tbody>
</table>
</div>




```python
lung_cancer_trunc.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LungCA</th>
      <th>age_group</th>
      <th>Gender</th>
      <th>CigSmoke_status</th>
      <th>Cigarette_number</th>
      <th>Cigarette_total</th>
      <th>Cooking_fumes</th>
      <th>Air_Pollution_Exposure</th>
      <th>Herbicide_day</th>
      <th>Number_Days_Insecticides_Use_432</th>
      <th>Number_Days_Fungicides_Use_433</th>
      <th>Glyphosate_days</th>
      <th>Paraquat_days</th>
      <th>two_four_Dichlorophenoxy_days</th>
      <th>Butachlor_Days</th>
      <th>Propanil_days</th>
      <th>Alachlor_days</th>
      <th>Endosalfan_days</th>
      <th>Dieldrin_days</th>
      <th>DDT_days</th>
      <th>Chlorpylifos_days</th>
      <th>Folidol_days</th>
      <th>Mevinphos_days</th>
      <th>Carbaryl_Savins_days</th>
      <th>Carbofuran_days</th>
      <th>Abamectin_days</th>
      <th>Armure_Propiconazole_days</th>
      <th>Metal_aldehyde_days</th>
      <th>ID</th>
      <th>Total_exposures</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>321</th>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>108.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>381</th>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>130.1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>172</th>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>640</td>
      <td>1400</td>
      <td>0</td>
      <td>160</td>
      <td>0</td>
      <td>0</td>
      <td>160</td>
      <td>0</td>
      <td>0</td>
      <td>640</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>120</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>640</td>
      <td>0</td>
      <td>0</td>
      <td>58.1</td>
      <td>640</td>
    </tr>
    <tr>
      <th>663</th>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1600</td>
      <td>1200</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1200</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>286.1</td>
      <td>1601</td>
    </tr>
    <tr>
      <th>291</th>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>10</td>
      <td>54750</td>
      <td>2</td>
      <td>0</td>
      <td>960</td>
      <td>600</td>
      <td>120</td>
      <td>80</td>
      <td>0</td>
      <td>80</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>138</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>120</td>
      <td>0</td>
      <td>98.0</td>
      <td>960</td>
    </tr>
  </tbody>
</table>
</div>




```python
g = sns.relplot(
    data=lung_cancer_trunc, kind="line",
    x="age_group", y="Total_exposures", 
    palette=palette, height=6,
    col='LungCA'
)
```


    
![png](output_30_0.png)
    



```python

g = sns.relplot(
    data=lung_cancer_trunc, kind="line",
    y='Cigarette_total', x="age_group", 
    palette=palette, height=5,
    col='LungCA'
)
```


    
![png](output_31_0.png)
    



```python
lung_cancer_trunc=pd.get_dummies(lung_cancer_trunc, columns=['CigSmoke_status'])
lung_cancer_trunc.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LungCA</th>
      <th>age_group</th>
      <th>Gender</th>
      <th>Cigarette_number</th>
      <th>Cigarette_total</th>
      <th>Cooking_fumes</th>
      <th>Air_Pollution_Exposure</th>
      <th>Herbicide_day</th>
      <th>Number_Days_Insecticides_Use_432</th>
      <th>Number_Days_Fungicides_Use_433</th>
      <th>Glyphosate_days</th>
      <th>Paraquat_days</th>
      <th>two_four_Dichlorophenoxy_days</th>
      <th>Butachlor_Days</th>
      <th>Propanil_days</th>
      <th>Alachlor_days</th>
      <th>Endosalfan_days</th>
      <th>Dieldrin_days</th>
      <th>DDT_days</th>
      <th>Chlorpylifos_days</th>
      <th>Folidol_days</th>
      <th>Mevinphos_days</th>
      <th>Carbaryl_Savins_days</th>
      <th>Carbofuran_days</th>
      <th>Abamectin_days</th>
      <th>Armure_Propiconazole_days</th>
      <th>Metal_aldehyde_days</th>
      <th>ID</th>
      <th>Total_exposures</th>
      <th>CigSmoke_status_1</th>
      <th>CigSmoke_status_2</th>
      <th>CigSmoke_status_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>435</th>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>10</td>
      <td>73000</td>
      <td>1</td>
      <td>1</td>
      <td>840</td>
      <td>900</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>960</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>840</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>960</td>
      <td>157.0</td>
      <td>841</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>232</th>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>78.1</td>
      <td>0</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>534</th>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>640</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>520</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>640</td>
      <td>201.1</td>
      <td>640</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>343</th>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>10</td>
      <td>156950</td>
      <td>2</td>
      <td>0</td>
      <td>1800</td>
      <td>0</td>
      <td>0</td>
      <td>160</td>
      <td>160</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>115.2</td>
      <td>1800</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>116</th>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>39.2</td>
      <td>0</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
g = sns.relplot(
    data=lung_cancer_trunc, kind="line",
    x="age_group", y="Total_exposures", 
    palette=palette, height=3,
    col='CigSmoke_status_1',style='LungCA'
)
g = sns.relplot(
    data=lung_cancer_trunc, kind="line",
    x="age_group", y="Total_exposures", 
    palette=palette, height=3,
    col='CigSmoke_status_2',style='LungCA'
)
g = sns.relplot(
    data=lung_cancer_trunc, kind="line",
    x="age_group", y="Total_exposures", 
    palette=palette, height=3,
    col='CigSmoke_status_3',style='LungCA'
)
```


    
![png](output_33_0.png)
    



    
![png](output_33_1.png)
    



    
![png](output_33_2.png)
    



```python
import scipy.stats
scipy.stats.spearmanr(lung_cancer_trunc['LungCA'], lung_cancer_trunc['CigSmoke_status_1'])
```




    SignificanceResult(statistic=-0.04839871711967859, pvalue=0.2074887175539296)




```python
scipy.stats.spearmanr(lung_cancer_trunc['LungCA'], lung_cancer_trunc['CigSmoke_status_2'])
```




    SignificanceResult(statistic=0.01719333047841422, pvalue=0.6544740809244423)




```python
scipy.stats.spearmanr(lung_cancer_trunc['LungCA'], lung_cancer_trunc['CigSmoke_status_3'])
```




    SignificanceResult(statistic=0.05242858352345508, pvalue=0.1720663765884992)




```python
scipy.stats.spearmanr(lung_cancer_trunc['LungCA'], lung_cancer_trunc['Total_exposures'])
```




    SignificanceResult(statistic=0.16666044194943433, pvalue=1.2506550626089275e-05)




```python
scipy.stats.spearmanr(lung_cancer_trunc['LungCA'], lung_cancer_trunc['Carbofuran_days'])
```




    SignificanceResult(statistic=0.142542298547309, pvalue=0.00019203626445637946)




```python
scipy.stats.spearmanr(lung_cancer_trunc['LungCA'], lung_cancer_trunc['Chlorpylifos_days'])
```




    SignificanceResult(statistic=0.16508915624391762, pvalue=1.5129066334868171e-05)




```python
scipy.stats.spearmanr(lung_cancer_trunc['LungCA'], lung_cancer_trunc['Cigarette_total'])
```




    SignificanceResult(statistic=0.07566217423721208, pvalue=0.04858382893908292)




```python
scipy.stats.spearmanr(lung_cancer_trunc['LungCA'], lung_cancer['age'])
```




    SignificanceResult(statistic=0.02534721112336145, pvalue=0.5093408746407553)



create new column Cig_plus_exposures the sum of total cigarettes smoked and total_exposures


```python
lung_cancer_trunc['Cig_plus_exposures'] = lung_cancer_trunc['Total_exposures']+lung_cancer_trunc['Cigarette_total']
lung_cancer_trunc.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LungCA</th>
      <th>age_group</th>
      <th>Gender</th>
      <th>Cigarette_number</th>
      <th>Cigarette_total</th>
      <th>Cooking_fumes</th>
      <th>Air_Pollution_Exposure</th>
      <th>Herbicide_day</th>
      <th>Number_Days_Insecticides_Use_432</th>
      <th>Number_Days_Fungicides_Use_433</th>
      <th>Glyphosate_days</th>
      <th>Paraquat_days</th>
      <th>two_four_Dichlorophenoxy_days</th>
      <th>Butachlor_Days</th>
      <th>Propanil_days</th>
      <th>Alachlor_days</th>
      <th>Endosalfan_days</th>
      <th>Dieldrin_days</th>
      <th>DDT_days</th>
      <th>Chlorpylifos_days</th>
      <th>Folidol_days</th>
      <th>Mevinphos_days</th>
      <th>Carbaryl_Savins_days</th>
      <th>Carbofuran_days</th>
      <th>Abamectin_days</th>
      <th>Armure_Propiconazole_days</th>
      <th>Metal_aldehyde_days</th>
      <th>ID</th>
      <th>Total_exposures</th>
      <th>CigSmoke_status_1</th>
      <th>CigSmoke_status_2</th>
      <th>CigSmoke_status_3</th>
      <th>Cig_plus_exposures</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>282</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>43800</td>
      <td>2</td>
      <td>1</td>
      <td>540</td>
      <td>750</td>
      <td>0</td>
      <td>1008</td>
      <td>0</td>
      <td>84</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>130</td>
      <td>0</td>
      <td>0</td>
      <td>960</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>95.0</td>
      <td>541</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>44341</td>
    </tr>
    <tr>
      <th>346</th>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>116.2</td>
      <td>1</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>1</td>
    </tr>
    <tr>
      <th>256</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>240</td>
      <td>360</td>
      <td>120</td>
      <td>0</td>
      <td>0</td>
      <td>360</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>86.1</td>
      <td>0</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>0</td>
    </tr>
    <tr>
      <th>265</th>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5760</td>
      <td>2880</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>89.1</td>
      <td>0</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>0</td>
    </tr>
    <tr>
      <th>140</th>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>20</td>
      <td>73000</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>800</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>400</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>400</td>
      <td>0</td>
      <td>0</td>
      <td>47.2</td>
      <td>1</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>73001</td>
    </tr>
  </tbody>
</table>
</div>




```python
g = sns.relplot(
    data=lung_cancer_trunc, kind="line",
    x="age_group", y="Cig_plus_exposures", 
    palette=palette, height=3,
    col='LungCA'
)

```


    
![png](output_44_0.png)
    



```python
scipy.stats.spearmanr(lung_cancer_trunc['Cig_plus_exposures'], lung_cancer_trunc['LungCA'])
```




    SignificanceResult(statistic=0.1064766750025258, pvalue=0.005446470559759582)




```python

```
